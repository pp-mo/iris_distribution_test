from setuptools import setup
setup(
    name = "iris-distrib-test",
    url='https://github.com/pp-mo/iris_distribution_test',
    download_url = 
      'https://github.com/pp-mo/iris_distribution_test/blob/master/dist/iris-distrib-test-0.0.2.tar.gz',
    version = "0.1.2",
    packages = ['iris_distribution_test'],
    author='ppmo',
    author_email='avd-support@metoffice.gov.uk',
)

